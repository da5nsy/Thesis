
The following files are licensed under the LPPL or released under CC0 terms as described in the README.md file that should have been distributed with this.

Additionally, the `.git-ignore` and `.travis.yaml` files in the original repository are released into the public domain under the Creative Commons CC0 1.0 Universal Public Domain Dedication. 

```
ucl-latex-thesis-templates
├── Appendices.tex
├── BibSettings.tex
├── Chapter2.tex
├── Chapter3.tex
├── Conclusions.tex
├── FloatSettings.tex
├── Introduction.tex
├── LinksAndMetadata.tex
├── MANIFEST.md
├── Main.tex
├── MainPackages.tex
├── Makefile
├── Preamble.tex
├── README.md
├── example.bib
└── ucl_thesis.cls
```
